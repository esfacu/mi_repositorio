from setuptools import setup

setup(
    name="mi_primer_paquete",
    version="1.0",
    author="Facundo Rodriguez",
    description="Estamos haciendo el primer paquete distribuido",
    author_email="facundo.m.rodriguez@outlook.com",
    packages=["mi_primer_paquete"]
)

# python setup.py sdist
