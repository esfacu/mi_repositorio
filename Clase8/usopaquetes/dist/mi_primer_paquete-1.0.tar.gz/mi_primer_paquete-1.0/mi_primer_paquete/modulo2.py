def llamando_al_modulo2():
    print("Acá estoy usando el modulo 2")