from setuptools import setup

setup(
    name="fechas",
    version="1.0",
    author="Facundo Rodriguez",
    packages=["fechas"]
)

# python setup.py sdist
